x = int(input("입력 : "))
if x > 0 :
    print("양수")
elif x == 0 :
    print("0")
else :
    print("음수")
