
'''
import os           #os.system() 함수를 사용하기 위한 설정

print("Hello~")     #실행할 코드

os.system('Pause')  #실행 창을 닫지 않도록 추가한 문장




'''
print("Hello~")   #실행할 코드

input()           #실행 창을 닫지 않도록 추가한 문장
