#벌집 그리기
from turtle import *

setup(800, 800)

for _ in range(6): # 6개의 정육각형을 위한 반복
    for _ in range(6): # 하나의 모양을 이루는 6개의 변을 위한 반복
        fd(100)
        lt(60)
    fd(100); rt(60) # 다음 모양을 그리기 위한 이동과 회전
