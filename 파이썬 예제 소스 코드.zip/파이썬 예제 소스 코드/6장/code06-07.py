
s = 0       # 합계를 저장하기 위한 변수

for x in range(0, 11):  # 0부터 10까지 반복
    s += x  # s = s + x와 동일, s가 x만큼 증가
    print(s, end = " ")

'''
# while 문으로 만드는 경우

x = 0
s = 0

while x <= 10:
    s = s + x
    print(s, end = " ")
    x = x + 1
'''
