# 사용자 정의 모듈 myprint

from datetime import *

def print_line() :
    print('*' * 30)

def print_title() :
    print_line()
    print("작성일 :", date.today())
    print_line()
