from myprint import *

contents = input("내용을 입력하세요. : ")

print_title()
print(contents)
print_line()

