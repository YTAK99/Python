from turtle import *
color("yellow", "gray")

def draw_circle(x, y, r = 100) :
    goto(x, y)
    begin_fill()
    circle(r)
    end_fill()
    return (3.14 * r ** 2)

print("원의 면적 = ", draw_circle(0, 0))
print("원의 면적 = ", draw_circle(300, 0, 50))

